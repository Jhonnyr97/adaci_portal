<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://themeforest.net/user/stylusthemes
 * @since      1.0.0
 *
 * @package    assurena_Core
 * @subpackage assurena_Core/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    assurena_Core
 * @subpackage assurena_Core/includes
 * @author     StylusThemes <stylusthemes@gmail.com>
 */
class assurena_Core_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
